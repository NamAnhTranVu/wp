<?php
/**
 * Plugin Name:     	KDN Madara
 * Description:     	<strong>This add-on will prevent conflicts between the <code>KDN Auto Leech</code> plugin and <code>Madara - Core</code> plugin. Ofcourse, this add-on also included many other features.</strong>
 * Version:         	1.0.3
 * Requires at least:   5.2
 * Requires PHP:        7.2
 * Plugin URI:      	https://kdnautoleech.com/add-ons
 * Author:          	KDN Auto Leech
 * Author URI:      	https://facebook.com/kdnautoleech
 * Text Domain:     	kdn-madara
 * Domain Path:     	app/lang
 * License:				GPLv3
 * License URI:			https://www.gnu.org/licenses/gpl-3.0.html
*/

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Require some files.
 */

if (!function_exists('get_plugin_data')) {
	include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

if (!function_exists('wp_get_current_user')) {
	include_once(ABSPATH . 'wp-includes/pluggable.php');
}

// Defined some constants.
if (!defined('KDN_MADARA_PATH')) {

    /**
     * The plugin path with a trailing slash.
     */
    define('KDN_MADARA_PATH', trailingslashit(plugin_dir_path(__FILE__)));
    define('KDN_MADARA_MAINFILE_PATH', __FILE__);
    define('KDN_MADARA_URL', trailingslashit(plugin_dir_url(__FILE__)));
    define('KDN_MADARA_VERSION', get_plugin_data(__FILE__)['Version']);

}

// Require autoload.
include_once('app/vendor/autoload.php');

// Call to controller.
new \KDNMadara\Controllers\Controller;