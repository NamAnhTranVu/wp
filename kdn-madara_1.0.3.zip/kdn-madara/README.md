# KDN Madara
This add-on will prevent conflicts between the **KDN Auto Leech** plugin and **Madara - Core** plugin. Ofcourse, this add-on also included many other features.

# Usage:

Activate
1. Activate plugin **KDN Madara**.
2. Activate plugin **KDN Auto Leech**.
3. Activate plugin **Madara - Core**.

Deactivate
1. Deactivate plugin **Madara - Core**.
2. Deactivate plugin **KDN Auto Leech**.
3. Deactivate plugin **KDN Madara**.