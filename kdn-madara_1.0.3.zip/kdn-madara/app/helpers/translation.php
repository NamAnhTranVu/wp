<?php

/**
 * A replacement function for translatable texts.
 *
 * @param   string      $string     Text to be translated.
 * @return  string                  Translated text.
 * 
 * @since   1.0.1
 */
function _kdnmadara($string) {

    // Return translated string.
    return __($string, 'kdn-madara');

}

/**
 * Debug log.
 * 
 * @param   mixed     $message    The debug message.
 * 
 * @since   1.0.1
 */
function _debug($message = '') {

    // Get "kdnmadara_options" data.
    $KDNMadaraOptions = get_option('kdnmadara_options', false);

    // If debug mode is ON.
    if (isset($KDNMadaraOptions['_debug_mode']) && $KDNMadaraOptions['_debug_mode']) {

        // Error log the message.
        error_log(print_r($message, true));

    }

}