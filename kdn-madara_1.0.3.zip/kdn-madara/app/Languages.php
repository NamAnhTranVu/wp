<?php
namespace KDNMadara;

/**
 * Languages.
 * 
 * @since   1.0.1
 */
class Languages {

    /**
     * Storage all languages.
     * 
     * @since   1.0.1
     */
    public static function getLanguages() {

        // Define all languages.
        $allLanguages = [
            0	=> _kdnmadara('Note:'),
            1	=> _kdnmadara('Activate plugin <b>KDN Madara</b>.'),
            2	=> _kdnmadara('Activate plugin <b>KDN Auto Leech</b>.'),
            3	=> _kdnmadara('Activate plugin <b>Madara - Core</b>.'),
            4	=> _kdnmadara('Chapter volume setting:'),
            5	=> _kdnmadara('KDN Madara will be take value from this post meta to create or assigns as chapter volume.'),
            6	=> _kdnmadara('Debug mode:'),
            7	=> _kdnmadara('Chapter name extend setting:'),
            8	=> _kdnmadara('KDN Madara will be take value from this post meta to create or assigns as chapter name extend.'),
            9	=> _kdnmadara('No title'),
            10	=> _kdnmadara('Activate'),
            11	=> _kdnmadara('Deactivate'),
			12	=> _kdnmadara('Deactivate plugin <b>Madara - Core</b>.'),
			13	=> _kdnmadara('Deactivate plugin <b>KDN Auto Leech</b>.'),
			14	=> _kdnmadara('Deactivate plugin <b>KDN Madara</b>.'),
        ];

        // Return all languages.
        return $allLanguages;

    }

}
