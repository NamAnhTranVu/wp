<?php
namespace KDNMadara;

/**
 * Utils.
 * 
 * @since   1.0.1
 */
class Utils {
    
    /**
     * Construct function.
     */
    public function __construct() {}

    /**
     * Get option.
     * 
     * @param   string		$optionName			The option name will be get data.
     * @param	mixed		$defaultValue		Default value to return if the option does not exist.
     * 
     * @return	mixed							The option value.
     * 
     * @since   1.0.1 
     */
    public static function KDNMadara_GetOption($optionName, $defaultValue = false) {

        // Get option value.
        return get_option($optionName, $defaultValue);

    }

    /**
     * Get post meta.
     * 
     * @param   int         $postId         The ID of post.
     * @param   string      $metaKey        The meta key to retrieve data from post.
     * @param   bool        $single         If true, returns only the first value for the specified meta key.
     * 
     * @return  mixed						The post meta value.
     * 
     * @since   1.0.1
     */
    public static function KDNMadara_GetPostMeta($postId, $metaKey = '', $single = false) {

        // Get post meta.
        return get_post_meta($postId, $metaKey, $single);

    }

}
