<?php
namespace KDNMadara\Models;
use KDNMadara\Languages;

/**
 * Manga chapter.
 * 
 * @since   1.0.1
 */
class MangaChapter {

    /**
     * Add manga chapter data for this chapter.
     * 
     * @param   array       $KDNMadaraOptions       An array contains the "kdnmadara_options" options.
     * @param   array       $data                   An array contains data to save post by "wp_insert_post" method.
     * @param   object      $postData               The PostData object.
     * @param   object      $postSaver              The PostSaver object.
     * @param   int         $siteId                 The ID of current campaign.
     * @param   string      $postUrl                The target URL.
     * @param   object      $urlTuple               The data of this target URL retrieve from database.
     * @param   bool        $isRecrawl              Whether to check this is recrawl or not.
     * @param   int         $postId                 The ID of post after saved.
     * @param   bool        $isFirstPage            Whether to check this is the first page or not.
     * @param   int         $chapterVolumeId        The ID of chapter volume for this chapter.
     * 
     * @return	array
     * 
     * @since   1.0.1
     */
    public static function KDNMadara_AddMangaChapter(
    	$KDNMadaraOptions, $data, $postData, $postSaver, $siteId, $postUrl, $urlTuple, $isRecrawl, $postId, $isFirstPage, $chapterVolumeId
	) {

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('= 2 ============================ [MangaChaper] =============================');
        // ------------------------ DEBUG MODE ------------------------ //

		// Get the all languages.
		$lang = Languages::getLanguages();

        // Define the chapter name.
        $chapterName = $data['post_title'];

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[MangaChaper] - Prepared manga chapter name: ' . $chapterName);
        // ------------------------ DEBUG MODE ------------------------ //

        // Get the ID of parent post (Manga ID).
        $mangaId = $urlTuple->saved_post_id ?: $data['post_parent'];

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[MangaChaper] - Manga ID: ' . $mangaId);
        // ------------------------ DEBUG MODE ------------------------ //

        // Get the prepared post meta.
        $preparePostMeta = $postData->getCustomMeta() ?: [];

        // Get the chapter name extend from post meta.
        $chapterNameExtend = '';
        foreach ($preparePostMeta as $key => $postMeta) {

            // If the "meta_key" is equal to the key "_kdn_chapter_name_extend" of "kdnmadara_options" option.
            if ($postMeta['meta_key'] == $KDNMadaraOptions['_kdn_chapter_name_extend']) {

                // Get the chapter volume name is "data" of this post "meta_key".
                $chapterNameExtend = $postMeta['data'];

                // Remove this post meta.
                unset($preparePostMeta[$key]);

                // Only one is enough.
                break;

            }

        }

        // Set post meta again without removed post meta above.
        $postData->setCustomMeta($preparePostMeta);

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[MangaChaper] - Prepared manga chapter name extend: ' . $chapterNameExtend);
        // ------------------------ DEBUG MODE ------------------------ //

        // Prepare the chapter slug.
        $chapterMainSlug    = get_post($postId)->post_name;
        $chapterMainSlug    = explode('___', $chapterMainSlug);
        $chapterSlug        = $chapterMainSlug[0];

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[MangaChaper] - Prepared manga chapter slug: ' . $chapterSlug);
        // ------------------------ DEBUG MODE ------------------------ //

        // Prepare the manga chapter id from chapter slug.
        $cacheChapterId      = (isset($chapterMainSlug[1]) && $chapterMainSlug[1]) ? $chapterMainSlug[1] : '';

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[MangaChaper] - Cache manga chapter ID: ' . $cacheChapterId);
        // ------------------------ DEBUG MODE ------------------------ //

        // Global WP Database.
        global $wpdb;

        // Define the table name.
        $tableName = $wpdb->prefix . 'manga_chapters';

        // Try to get the exist managa chapter data for this chapter.
        $existMangaChapterData = '';

        if ($cacheChapterId) {

            $existMangaChapterData = $wpdb->get_row(
                "SELECT *
                    FROM {$tableName}
                    WHERE chapter_id = '{$cacheChapterId}' AND post_id = {$mangaId}"
            );

        }

        // If we have an exist manga chapter data.
        if ($existMangaChapterData) {

            // Update the exist manga chapter.
            $wpdb->update(
                $tableName,
                [
                    'post_id'	            => $mangaId,
                    'volume_id'             => $chapterVolumeId,
                    'chapter_name'	        => $chapterName ?: $lang[9],
                    'chapter_name_extend'	=> $chapterNameExtend,
                    'chapter_slug'	        => $chapterSlug,
                    'date'			        => current_time('mysql'),
                    'date_gmt'			    => current_time('mysql')
                ],
                [
                    'chapter_id'            => $existMangaChapterData->chapter_id
                ]
            );

            // Get the ID of exist manga chapter.
            $mangaChapterId = $existMangaChapterData->chapter_id;

            // ------------------------ DEBUG MODE ------------------------ //
            _debug('[MangaChaper] - Updated manga chapter ID: ' . $mangaChapterId);
            // ------------------------ DEBUG MODE ------------------------ //

        }

		// Otherwise, create new manga chapter.
        else {

            // Insert new manga chapter.
            $wpdb->insert(
                $tableName,
                [
                    'post_id'	            => $mangaId,
                    'volume_id'             => $chapterVolumeId,
                    'chapter_name'	        => $chapterName ?: $lang[9],
                    'chapter_name_extend'	=> $chapterNameExtend,
                    'chapter_slug'	        => $chapterSlug,
                    'date'			        => current_time('mysql'),
                    'date_gmt'			    => current_time('mysql')
                ]
            );

            // Get the ID of new managa chapter.
            $mangaChapterId = $wpdb->insert_id;

            // ------------------------ DEBUG MODE ------------------------ //
            _debug('[MangaChaper] - Inserted new manga chapter ID: ' . $mangaChapterId);
            // ------------------------ DEBUG MODE ------------------------ //

			update_post_meta($mangaId, '_latest_update', current_time( 'timestamp', false ));

			// ------------------------ DEBUG MODE ------------------------ //
			_debug('[MangaChaper] - Update post meta "last_update" for Manga ID: ' . $mangaId);
			// ------------------------ DEBUG MODE ------------------------ //

        }

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[MangaChaper] - Return manga chapter data ↴');
        _debug('[MangaChaper] - + Post parent ID: ' . $mangaChapterId);
        _debug('[MangaChaper] - + Post name: ' . $chapterSlug . '___' . $mangaChapterId);
        // ------------------------ DEBUG MODE ------------------------ //

        // Prepare the manga chapter data.
        $mangaChapterData = [
            'id'        => $mangaChapterId,
            'slug'      => $chapterSlug . '___' . $mangaChapterId
        ];

        // Return manga chapter data.
        return $mangaChapterData;

    }

}