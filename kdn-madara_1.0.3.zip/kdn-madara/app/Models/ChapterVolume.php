<?php
namespace KDNMadara\Models;

/**
 * Chapter volume.
 * 
 * @since   1.0.1
 */
class ChapterVolume {

	/**
	 * Get the ID of chapter volume for this chapter.
	 *
	 * @param    array		$KDNMadaraOptions		An array contains all options.
	 * @param    array     	$data           		An array contains data to save post by "wp_insert_post" method.
	 * @param    object    	$postData       		The PostData object.
	 * @param    object    	$postSaver      		The PostSaver object.
	 * @param    int       	$siteId         		The ID of current campaign.
	 * @param    string    	$postUrl        		The target URL.
	 * @param    object    	$urlTuple       		The data of this target URL retrieve from database.
	 * @param    bool      	$isRecrawl      		Whether to check this is recrawl or not.
	 * @param    int       	$postId         		The ID of post after saved.
	 * @param    bool      	$isFirstPage    		Whether to check this is the first page or not.
	 *
	 * @return  int			$chapterVolumeId    The ID of chapter volume for this chapter.
	 *
	 * @since   1.0.1
	 */
    public static function KDNMadara_GetVolumeId(
    	$KDNMadaraOptions, $data, $postData, $postSaver, $siteId, $postUrl, $urlTuple, $isRecrawl, $postId, $isFirstPage
	) {

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('= 1 =========================== [ChapterVolume] ============================');
        // ------------------------ DEBUG MODE ------------------------ //

        // Get the prepared post meta.
        $preparePostMeta = $postData->getCustomMeta();

        // If do not have any prepared post meta, stop.
        if (empty($preparePostMeta)) {

            // ------------------------ DEBUG MODE ------------------------ //
            _debug('[ChapterVolume] - Not have any prepared post meta, stop!');
            // ------------------------ DEBUG MODE ------------------------ //

            return 0;

        }

        // Get the chapter volume name from post meta.
        $chapterVolumeName = '';
        foreach ($preparePostMeta as $key => $postMeta) {

            // If the "meta_key" is equal to the key "_kdn_chapter_volume" of "kdnmadara_options" option.
            if ($postMeta['meta_key'] == $KDNMadaraOptions['_kdn_chapter_volume']) {

                // Get the chapter volume name is "data" of this post "meta_key".
                $chapterVolumeName = $postMeta['data'];

                // Remove this post meta.
                unset($preparePostMeta[$key]);

                // Only one is enough.
                break;

            }

        }

        // Set post meta again without removed post meta above.
        $postData->setCustomMeta($preparePostMeta);

        // If emply chapter volume name, stop.
        if (!$chapterVolumeName) {

            // ------------------------ DEBUG MODE ------------------------ //
            _debug('[ChapterVolume] - Chapter volume name is empty, stop!');
            // ------------------------ DEBUG MODE ------------------------ //

            return 0;

        }

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[ChapterVolume] - Prepared chapter volume name: ' . $chapterVolumeName);
        // ------------------------ DEBUG MODE ------------------------ //

        // Get the ID of parent post (Manga ID).
        $mangaId = $urlTuple->saved_post_id ?: $data['post_parent'];

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[ChapterVolume] - Manga ID: ' . $mangaId);
        // ------------------------ DEBUG MODE ------------------------ //

        // Global WP Database.
        global $wpdb;
        
        // Define the table name of manga volumes.
        $tableName = $wpdb->prefix . 'manga_volumes';

        // Try to get the ID of exist chapter volume.
        $chapterVolumeRow = $wpdb->get_row(
            "SELECT volume_id
                FROM {$tableName}
                WHERE volume_name = '{$chapterVolumeName}' AND post_id = {$mangaId}"
        );

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[ChapterVolume] - Exist chapter volume ID: ' . ($chapterVolumeRow ? $chapterVolumeRow->volume_id : 'N/a'));
        // ------------------------ DEBUG MODE ------------------------ //
        
        if ($chapterVolumeRow) {

            // Get the ID of exist chapter volume.
            $chapterVolumeId = $chapterVolumeRow->volume_id;

        } else {

            // ------------------------ DEBUG MODE ------------------------ //
            _debug('[ChapterVolume] - Create new chapter volume ↴');
            // ------------------------ DEBUG MODE ------------------------ //

            // Get count chapter volumes.
            $countChapterVolumes = count($wpdb->get_results(
                "SELECT *
                    FROM {$tableName}
                    WHERE post_id = {$mangaId}"
            ));
    
            // ------------------------ DEBUG MODE ------------------------ //
            _debug('[ChapterVolume] - + New chapter volume "post_id": ' . $mangaId);
            _debug('[ChapterVolume] - + New chapter volume "volume_name": ' . $chapterVolumeName);
            _debug('[ChapterVolume] - + New chapter volume "date": ' . current_time('mysql'));
            _debug('[ChapterVolume] - + New chapter volume "date_gmt": ' . current_time('mysql'));
            _debug('[ChapterVolume] - + New chapter volume "volume_index": ' . $countChapterVolumes);
            // ------------------------ DEBUG MODE ------------------------ //

            // Insert new chapter volume.
            $wpdb->insert($tableName, [
                'post_id'           => $mangaId,
                'volume_name'       => $chapterVolumeName,
                'date'              => current_time('mysql'),
                'date_gmt'          => current_time('mysql'),
                'volume_index'      => $countChapterVolumes
            ]);
            
            // Get the ID of new chapter volume.
            $chapterVolumeId = $wpdb->insert_id;
            
        }

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[ChapterVolume] - Return chapter volume ID: ' . $chapterVolumeId);
        // ------------------------ DEBUG MODE ------------------------ //

        // Return chapter volume ID.
        return $chapterVolumeId;

    }

}
