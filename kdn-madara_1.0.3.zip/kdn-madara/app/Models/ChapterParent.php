<?php
namespace KDNMadara\Models;

/**
 * Update chapter "post_parent" and "post_name".
 * 
 * @since   1.0.1
 */
class ChapterParent {

    /**
     * Update chapter "post_parent" and "post_name".
     * 
     * @param   int     $postId                     The ID of post which will be updated.
     * @param   array   $mangaChapterData           The manga chapter data.
     * 
     * @since   1.0.1
     */
    public static function KDNMadara_UpdateChapterPostParentAndPostName($postId, $mangaChapterData) {

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('= 3 =========================== [ChapterParent] ============================');
        // ------------------------ DEBUG MODE ------------------------ //

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[ChapterParent] - Post ID: ' . $postId);
        _debug('[ChapterParent] - Post parent ID: ' . $mangaChapterData['id']);
        _debug('[ChapterParent] - Post name: ' . $mangaChapterData['slug']);
        // ------------------------ DEBUG MODE ------------------------ //

        // Prepare the post arguments.
        $args = [
            'ID'            => $postId,
            'post_parent'   => $mangaChapterData['id'],
            'post_name'     => $mangaChapterData['slug']
        ];

        // Update post.
        wp_update_post($args);

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('[ChapterParent] - Done!'); _debug(''); _debug('');
        // ------------------------ DEBUG MODE ------------------------ //

    }

}