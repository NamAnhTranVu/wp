<?php
namespace KDNMadara\Models;
use KDNMadara\Utils;
use KDNMadara\Models\ChapterVolume;
use KDNMadara\Models\MangaChapter;
use KDNMadara\Models\ChapterParent;

/**
 * Execute chapters.
 * 
 * @since   1.0.1
 */
class EXChapter {

	/** @var 	array		The "kdnmadara_options" data. */
    private $KDNMadaraOptions;

    /**
     * Construct function.
     */
    public function __construct() {

		// Get the "kdnmadara_options" data.
		$this->KDNMadaraOptions = Utils::KDNMadara_GetOption('kdnmadara_options');
        
        // KDN Post - After save action.
        add_action('kdn/post/after_save', [$this, 'KDNMadara_KDNPostAfterSave'], 10, 9);

    }

    /**
     * KDN Post - After save action callback.
     * 
     * @param   array       $data           An array contains data to save post by "wp_insert_post" method.
     * @param   object      $postData       The PostData object.
     * @param   object      $postSaver      The PostSaver object.
     * @param   int         $siteId         The ID of current campaign.
     * @param   string      $postUrl        The target URL.
     * @param   object      $urlTuple       The data of this target URL retrieve from database.
     * @param   bool        $isRecrawl      Whether to check this is recrawl or not.
     * @param   int         $postId         The ID of post after saved.
     * @param   bool        $isFirstPage    Whether to check this is the first page or not.
     * 
     * @since   1.0.1
     */
    public function KDNMadara_KDNPostAfterSave($data, $postData, $postSaver, $siteId, $postUrl, $urlTuple, $isRecrawl, $postId, $isFirstPage) {

        // If this is the first page, stop.
        if ($isFirstPage && !$postSaver->lastPageNow()) return;

        // ------------------------ DEBUG MODE ------------------------ //
        _debug('EXECUTE CHAPTER ↴');
        // ------------------------ DEBUG MODE ------------------------ //

        // Get the ID of chapter volume for this chapter.
        $chapterVolumeId    = ChapterVolume::KDNMadara_GetVolumeId(
            $this->KDNMadaraOptions,
            $data, $postData, $postSaver, $siteId, $postUrl, $urlTuple, $isRecrawl, $postId, $isFirstPage
        );
        
        // Get the manga chapter data for this chapter.
        $mangaChapterData  = MangaChapter::KDNMadara_AddMangaChapter(
            $this->KDNMadaraOptions,
            $data, $postData, $postSaver, $siteId, $postUrl, $urlTuple, $isRecrawl, $postId, $isFirstPage,
            $chapterVolumeId
        );

        // Update "post_parent" and "post_name" of this chapter with manga chapter data above.
        ChapterParent::KDNMadara_UpdateChapterPostParentAndPostName($postId, $mangaChapterData);

    }
    
}
