<?php
namespace KDNMadara\Controllers;
use KDNMadara\Languages;
use KDNMadara\Utils;

/**
 * Menu.
 * 
 * @since   1.0.1
 */
class Menu {

	/** @var 	array		The "kdnmadara_options". */
	private $KDNMadaraOptions;
	/** @var 	array		The all languages. */
	private $lang;

    /**
     * Construct function.
     */
    public function __construct() {

		// Get all options.
		$this->KDNMadaraOptions = 	Utils::KDNMadara_GetOption('kdnmadara_options');

        // Add a submenu page.
        add_action('admin_menu', 	[$this, 'KDNMadara_Menu']);

		// Create options.
		add_action('admin_init', 	[$this, 'KDNMadara_Options']);

    }

    /**
     * Add a submenu page callback.
     * 
     * @since   1.0.1
     */
    public function KDNMadara_Menu() {

		// Get the all languages.
		$this->lang = Languages::getLanguages();

		// Define parent page for this submenu.
		$parentPage = 'plugins.php';
		if (defined('KDN_AUTO_LEECH_VERSION')) {
			if (version_compare(KDN_AUTO_LEECH_VERSION, '2.3.6', '>')) {
				$parentPage = 'edit.php?post_type=kdn_sites';
			}
		}

		// Add submenu page.
        add_submenu_page(
            $parentPage,													// Parent page
            _kdnmadara('KDN Madara'),										// Title
            _kdnmadara('+ KDN Madara'),										// Menu
            'administrator',												// Capability
            'kdn-madara',													// Slug
            [$this, 'KDNMadara_MenuContent']								// Callback
		);
		
    }

	/**
	 * Default options.
	 * 
	 * @return	array	$defaultOptions		The default options if not have any options.
	 *
	 * @since 	1.0.1
	 */
	private function defaultOptions() {

		// Define the default options.
		$defaultOptions = [
			'_kdn_chapter_volume'			=> '_kdn_chapter_volume',
			'_kdn_chapter_name_extend'		=> '_kdn_chapter_name_extend'
		];

		// Return default options.
		return $defaultOptions;

	}

	/**
	 * Create options callback.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_Options() {
	 
		// If the options don't exist, create them.
		if (!$this->KDNMadaraOptions) {
		    add_option('kdnmadara_options', $this->defaultOptions());
		}

		/**
		 * Add sections and fields.
		 */

		// Register a section.
		add_settings_section(
		    'kdnmadara_options',         									// ID
		    null,                  											// Title
		    [$this, 'KDNMadara_OptionsCallback'], 							// Callback
		    'kdnmadara_options_screen'     									// Screen
		);
	    
	    // Chapter volume.
	    add_settings_field(
	        'kdnmadara_chapter_volume',										// ID
	        $this->lang[4] . '<small>' . $this->lang[5] . '</small>',		// Label
	        [$this, 'KDNMadara_ChapterVolume_Callback'],   					// Callback
	        'kdnmadara_options_screen',										// Screen
	        'kdnmadara_options',         									// Section
	        ['']															// Arguments
	    );
	    
	    // Chapter name extend.
	    add_settings_field(
	        'kdnmadara_chapter_name_extend',								// ID
	        $this->lang[7] . '<small>' . $this->lang[8] . '</small>',		// Label
	        [$this, 'KDNMadara_ChapterNameExtend_Callback'],   				// Callback
	        'kdnmadara_options_screen',										// Screen
	        'kdnmadara_options',         									// Section
	        ['']															// Arguments
	    );
	    
	    // Debug mode.
	    add_settings_field(
	        'kdnmadara_debug_mode',											// ID
	        $this->lang[6],													// Label
	        [$this, 'KDNMadara_DebugMode_Callback'],   						// Callback
	        'kdnmadara_options_screen',										// Screen
	        'kdnmadara_options',         									// Section
	        ['']															// Arguments
	    );

		/**
		 * Register option.
		 */

		// Register option "kdnmadara_options".
		register_setting(
			'kdnmadara_options_screen',										// Screen
			'kdnmadara_options',											// Option
			null
		);
	     
	}

	/**
	 * Section callback.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_OptionsCallback() {}

	/**
	 * Chapter volume callback.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_ChapterVolume_Callback() {

		// Initialize HTML.
		$html = '	<input type="text"
						name="kdnmadara_options[_kdn_chapter_volume]"
						placeholder="Post meta"
						value="'. $this->KDNMadaraOptions['_kdn_chapter_volume'] .'"
					/>
				';
					
	    echo $html;

	}

	/**
	 * Chapter name extend callback.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_ChapterNameExtend_Callback() {

		// Initialize HTML.
		$html = '	<input type="text"
						name="kdnmadara_options[_kdn_chapter_name_extend]"
						placeholder="Post meta"
						value="'. $this->KDNMadaraOptions['_kdn_chapter_name_extend'] .'"
					/>
				';
					
	    echo $html;

	}

	/**
	 * Debug mode callback.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_DebugMode_Callback() {
		
		$debugMode = isset($this->KDNMadaraOptions['_debug_mode']) ? true : false;

		// Initialize HTML.
		$html = '	<input type="checkbox"
						name="kdnmadara_options[_debug_mode]"
						value="1"
						'. ($debugMode ? 'checked' : '') .'
					/>
				';
					
	    echo $html;

	}

	/**
	 * Render menu page content.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_MenuContent() {
	?>
	    <div class="wrap">
	     
	        <h1>KDN Madara</h1>

	        <?php settings_errors(); ?>

	        <!-- CONTENT -->
	        <form method="POST" action="options.php" class="kdnmadara_options">
				<?php
					settings_fields('kdnmadara_options_screen');
					do_settings_sections('kdnmadara_options_screen');
					submit_button();
				?>
			</form>
	         
	    </div>
	<?php
	}

}
