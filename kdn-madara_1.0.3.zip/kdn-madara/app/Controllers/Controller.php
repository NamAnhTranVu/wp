<?php
namespace KDNMadara\Controllers;
use KDNMadara\Controllers\Menu;
use KDNMadara\Models\EXChapter;
use KDNMadara\Languages;

/**
 * Controller.
 * 
 * @since   1.0.1
 */
class Controller {

    /** @var    array   The all languages. */
    private $lang;

    /**
     * Construct function.
     */
    public function __construct() {

        // Set the folder including translation files, and handle translations.
        add_action('plugins_loaded', function() {

            // Load plugin languages.
            load_plugin_textdomain('kdn-madara', false, 'kdn-madara/app/lang/');

            // Get the all languages.
            $this->lang = Languages::getLanguages();

        });
        
        // Remove AWS Autoloader when this plugin activated.
        register_activation_hook(KDN_MADARA_MAINFILE_PATH,		[$this, 'KDNMadara_RemoveAmazonUpload']);

        // Restore AWS Autoloader when this plugin deactivated.
        register_deactivation_hook(KDN_MADARA_MAINFILE_PATH,	[$this, 'KDNMadara_RestoreAmazonUpload']);

		// Admin enqueue scripts.
        add_action('admin_enqueue_scripts',							[$this, 'KDNMadara_AdminEnqueueScripts'], 9999);

        add_filter('amazon_s3_args', 								[$this, 'KDNMadara_AmazonS3Args'], 10, 1);
        
        // Create menu.
        new Menu;

        // Execute chapters.
        new EXChapter;

    }

    /**
     * Remove AWS Autoloader.
     * 
     * @since   1.0.1
     */
    public function KDNMadara_RemoveAmazonUpload() {

		if (defined('WP_MANGA_FILE')) {
			deactivate_plugins(WP_MANGA_FILE);
		}

        // Define some parameters.
        $removed    = false;
        $file       = WP_PLUGIN_DIR . '/madara-core/lib/amazons3/aws-autoloader.php';

        // Open the file.
        $fileHandle = fopen($file, 'r');

        // If the file opened.
        if ($fileHandle) {

            // Read the content in that file.
            $content = fread($fileHandle, filesize($file));

            // If not have "KDN_REMOVED" that means this file do not have any fix before.
            // So we will fix it.
            if (strpos($content, 'KDN_REMOVED') == false) {

                // Remove AWS Autoloader.
                $content = preg_replace('/require(.+?)uzzle/i', '// KDN_REMOVED require$1uzzle', $content);

                // Define the "removed" parameter to "true".
                $removed = true;

            }

        }

        // If the "removed" parameter is "true".
        if ($removed) {

            // Open that file again with "write" permission.
            $fileHandle = fopen($file, 'w');

            // If the file opened.
            if ($fileHandle) {

                // Write the new content into that file.
                fwrite($fileHandle, $content);

            }

        }

        // Close that file.
        fclose($fileHandle);
        
    }

    /**
     * Restore AWS Autoloader.
     * 
     * @since   1.0.1
     */
    public function KDNMadara_RestoreAmazonUpload() {

        // Define some parameters.
        $restored   = false;
        $file       = WP_PLUGIN_DIR . '/madara-core/lib/amazons3/aws-autoloader.php';

        // Open the file.
        $fileHandle = fopen($file, 'r');

        // If the file opened.
        if ($fileHandle) {

            // Read the content in that file.
            $content = fread($fileHandle, filesize($file));

            // If have "KDN_REMOVED" that means this file have fix before.
            // So we will restore it.
            if (strpos($content, 'KDN_REMOVED') !== false) {

                // Remove AWS Autoloader.
                $content = preg_replace('/\/\/ KDN_REMOVED require/i', 'require', $content);

                // Define the "restored" parameter to "true".
                $restored = true;

            }

        }

        // If the "restored" parameter is "true".
        if ($restored) {

            // Open that file again with "write" permission.
            $fileHandle = fopen($file, 'w');

            // If the file opened.
            if ($fileHandle) {

                // Write the new content into that file.
                fwrite($fileHandle, $content);

            }

        }

        // Close that file.
        fclose($fileHandle);
        
    }

	/**
	 * Admin enqueue scripts.
	 *
	 * @since 	1.0.1
	 */
	public function KDNMadara_AdminEnqueueScripts() {

		// Enqueue CSS.
        wp_enqueue_style('kdn-madara',      KDN_MADARA_URL . 'app/public/css/backend.css', 		null, KDN_MADARA_VERSION);

        // Enqueue JS.
        wp_enqueue_script('kdn-madara',     KDN_MADARA_URL . 'app/public/dist/backend/main.js',	null, KDN_MADARA_VERSION, true);
        wp_localize_script('kdn-madara',    'KDN_Madara_JS_Localize_Backend',
            array(
                'kdn_madara_url'    => KDN_MADARA_URL,
                'ajax_url'          => admin_url('admin-ajax.php'),
                'wp_nonce'          => wp_create_nonce('kdn-madara'),
                'pluginRowContent'  => '<div class="note-plugin-row">
                                            <p><strong><font color="limegreen">' . $this->lang[10] . '</font></strong></p>
                                            <ol>
                                                <li>' . $this->lang[1] . '</li>
                                                <li>' . $this->lang[2] . '</li>
                                                <li>' . $this->lang[3] . '</li>
                                            </ol>
                                            <p><strong><font color="red">' . $this->lang[11] . '</font></strong></p>
                                            <ol>
                                                <li>' . $this->lang[12] . '</li>
                                                <li>' . $this->lang[13] . '</li>
                                                <li>' . $this->lang[14] . '</li>
                                            </ol>
                                        </div>',
            )
        );
        
	}

	/**
	 * @param 	array	$args		The Amazon S3 Uploader arguments.
	 *
	 * @return	mixed
	 */
	public function KDNMadara_AmazonS3Args($args) {
		$args['scheme'] = 'http';
		return $args;
	}

}
