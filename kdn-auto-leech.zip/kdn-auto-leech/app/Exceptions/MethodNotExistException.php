<?php

namespace KDNAutoLeech\Exceptions;


class MethodNotExistException extends \Exception {

}