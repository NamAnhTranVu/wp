<?php

namespace KDNAutoLeech\Exceptions;


class DuplicatePostException extends \Exception {

}