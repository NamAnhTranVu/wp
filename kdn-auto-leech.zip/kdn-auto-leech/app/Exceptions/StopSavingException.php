<?php

namespace KDNAutoLeech\Exceptions;


class StopSavingException extends \Exception {

}