<?php
    // Define a variable to understand if this is the general page. If not, this settings is in post settings page.
    // Take some actions according to this.
    $isGeneralPage = isset($isGeneralPage) && $isGeneralPage;
?>

<div class="kdn-settings-title">
    <h3><?php echo e(_kdn('Advanced')); ?></h3>
    <span><?php echo e(_kdn('Advanced settings for crawler')); ?></span>
</div>

<table class="kdn-settings">

    
    <?php if($isGeneralPage): ?>
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', [
                    'for'   =>  '_kdn_js_cron',
                    'title' =>  _kdn('JS Cron Interval'),
                    'info'  =>  _kdn('Set interval for JS Cron (in seconds). Set 0 if you do not want to use JS Cron.')
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/text', [
                    'name'      =>  '_kdn_js_cron',
                    'type'      =>  'number',
                    'min'       =>  0
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <?php echo $__env->make('form-items.combined.checkbox-with-label', [
        'name'  => '_kdn_make_sure_encoding_utf8',
        'title' =>  _kdn('Always use UTF8 encoding?'),
        'info'  =>  _kdn('If you want to crawl all pages in UTF-8 encoding, check this.'),
        'dependants' => '["#convert-encoding"]',
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('form-items.combined.checkbox-with-label', [
        'name'  => '_kdn_convert_charset_to_utf8',
        'title' => _kdn('Convert encoding to UTF8 when it is not UTF8'),
        'info'  => _kdn('If you want to convert the encoding of the HTML retrieved from target sites to UTF8 when
            it has a different encoding, check this.'),
        'id'    => 'convert-encoding',
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_http_user_agent',
                'title' =>  _kdn('HTTP User Agent'),
                'info'  =>  _kdn('The user agent to be used when crawling, i.e.
                <span class="highlight variable">HTTP_USER_AGENT</span>. If you leave this empty, the default value
                will be used. You can find user agent strings
                <a target="_blank" href="http://www.useragentstring.com/pages/useragentstring.php">here</a>.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name'      =>  '_kdn_http_user_agent',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_http_accept',
                'title' =>  _kdn('HTTP Accept'),
                'info'  =>  _kdn('HTTP accept value to be used when crawling, i.e.
                    <span class="highlight variable">HTTP_ACCEPT</span>. If you leave this empty, the default value
                    will be used.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name'      =>  '_kdn_http_accept',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_http_allow_cookies',
                'title' =>  _kdn('Allow cookies?'),
                'info'  =>  _kdn('If you want to allow cookies when crawling, check this.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'      =>  '_kdn_http_allow_cookies',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_connection_timeout',
                'title' =>  _kdn('Connection timeout (in seconds)'),
                'info'  =>  _kdn('Maximum number of seconds in which target server should response. Write 0 to disable.
                        Default: 0')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name'      =>  '_kdn_connection_timeout',
                'type'      =>  'number',
                'min'       =>  0
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_use_proxy',
                'title' =>  _kdn('Use proxy?'),
                'info'  =>  _kdn('If you want to use a proxy when crawling the target site, check this.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'          =>  '_kdn_use_proxy',
                'dependants'    =>  '["#proxy-test-url", "#proxies", "#proxy-try-limit", "#proxy-randomize"]',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr id="proxy-test-url">
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_test_url_proxy',
                'title' =>  _kdn('URL for proxy testing'),
                'info'  =>  _kdn('A URL to be used to perform the proxy test.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td><?php echo $__env->make('form-items/text', ['name' => '_kdn_test_url_proxy', 'type' => 'url'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
    </tr>

    
    <tr id="proxies">
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_proxies',
                'title' =>  _kdn('Proxies'),
                'info'  =>  _kdn('You can write your proxies here. Write every proxy in a new line. If you want to
                        use a proxy specifically with a protocol, write the proxy with its protocol. E.g.
                        <span class="highlight proxy">https://192.168.16.1:10</span>, or
                        <span class="highlight proxy">http://192.168.16.1:10</span>. You can also provide proxies
                        that contain a scheme, username and password. E.g.
                        <span class="highlight proxy">http://username:password@192.168.16.1:10</span>. If you do not
                        specify the protocol, TCP will be used. SOCKS is not supported.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_kdn_proxies',
                'placeholder'   =>  _kdn('New line-separated proxies...'),
                'data'          =>  [
                    'urlSelector'   =>  "#_kdn_test_url_proxy",
                    'testType'      =>  \KDNAutoLeech\Test\Test::$TEST_TYPE_PROXY,
                ],
                'addon'         =>  'dashicons dashicons-search',
                'test'          =>  true,
                'addonClasses'  => 'kdn-test-proxy',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr id="proxy-try-limit">
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_proxy_try_limit',
                'title' =>  _kdn('Proxy try limit'),
                'info'  =>  _kdn('Maximum number of proxies that can be tried for one request. Write 0 for no limitation.
                        Default: 0')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name'      =>  '_kdn_proxy_try_limit',
                'type'      =>  'number',
                'min'       =>  0
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr id="proxy-randomize">
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_proxy_randomize',
                'title' =>  _kdn('Randomize proxies'),
                'info'  =>  _kdn('When you check this, the proxies you entered will be randomized. This means, the order
                    of the proxies will be changed every time before a new request is made. If you do not check this,
                    the proxies will be tried in the order you entered them.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'          =>  '_kdn_proxy_randomize'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    <?php

    /**
     * Fires before closing table tag in advanced tab of general settings page.
     *
     * @param array $settings       Existing settings and their values saved by user before
     * @param bool  $isGeneralPage  True if this is called from a general settings page.
     * @param bool  $isOption       True if this is an option, instead of a setting. A setting is a post meta, while
     *                              an option is a WordPress option. This is true when this is fired from general
     *                              settings page.
     * @since 1.6.3
     */
    do_action('kdn/view/general-settings/tab/advanced', $settings, $isGeneralPage, $isOption);

    ?>

</table>