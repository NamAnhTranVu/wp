<button class="button test-this"
        data-url="<?php echo e($url); ?>"
        data-type="<?php echo e($type); ?>"
        title="<?php echo e(_kdn('Test this URL')); ?>">
    <span class="dashicons dashicons-search"></span>
</button>