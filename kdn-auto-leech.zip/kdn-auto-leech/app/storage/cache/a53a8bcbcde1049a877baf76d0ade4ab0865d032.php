<div class="input-group find-replace-in-custom-meta <?php echo e(isset($addon) ? 'addon' : ''); ?> <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <?php if(isset($addon)): ?>
        <?php echo $__env->make('form-items.partials.button-addon-test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="input-container">
        <input type="checkbox" name="<?php echo e($name . '[regex]'); ?>" id="<?php echo e($name . '[regex]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Regex?')); ?>"
            <?php if(isset($value['regex'])): ?> checked="checked" <?php endif; ?> tabindex="0">

        <input type="checkbox" name="<?php echo e($name . '[callback]'); ?>" id="<?php echo e($name . '[callback]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Callback?')); ?>"
            <?php if(isset($value['callback'])): ?> checked="checked" <?php endif; ?>>

        <input type="checkbox" name="<?php echo e($name . '[spin]'); ?>" id="<?php echo e($name . '[spin]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Spinner?')); ?>"
            <?php if(isset($value['spin'])): ?> checked="checked" <?php endif; ?>>

        <input type="text" name="<?php echo e($name . '[meta_key]'); ?>" id="<?php echo e($name . '[meta_key]'); ?>" placeholder="<?php echo e(_kdn('Meta key')); ?>"
               value="<?php echo e(isset($value['meta_key']) ? $value['meta_key'] : ''); ?>" class="meta-key" tabindex="0">

        <input type="text" name="<?php echo e($name . '[find]'); ?>" id="<?php echo e($name . '[find]'); ?>" placeholder="<?php echo e(_kdn('Find')); ?>"
            value="<?php echo e(isset($value['find']) ? $value['find'] : ''); ?>" tabindex="0">

        <textarea name="<?php echo e($name . '[replace]'); ?>" id="<?php echo e($name . '[replace]'); ?>" placeholder="<?php echo e(_kdn('Replace')); ?>" tabindex="0"><?php echo e(isset($value['replace']) ? $value['replace'] : ''); ?></textarea>
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>