<?php $__env->startSection('title'); ?>
    <?php echo e(_kdn("Clear URLs")); ?>

<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <form action="" class="tool-form">
        

        <?php echo $__env->make('partials.form-nonce-and-action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <input type="hidden" name="tool_type" value="delete_urls">

        <div class="panel-wrap kdn-settings-meta-box">

            <table class="kdn-settings">
                
                <tr>
                    <td>
                        <?php echo $__env->make('form-items/label', [
                            'for'   =>  '_kdn_tools_site_id',
                            'title' =>  _kdn('Site'),
                            'info'  =>  _kdn('Select the site whose URLs you want to be deleted from the database.'),
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                    <td>
                        <?php echo $__env->make('form-items/select', [
                            'name'      =>  '_kdn_tools_site_id',
                            'options'   =>  $sites,
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                </tr>

                
                <tr>
                    <td>
                        <?php echo $__env->make('form-items/label', [
                            'for'   =>  '_kdn_tools_url_type',
                            'title' =>  _kdn('URL Type'),
                            'info'  =>  _kdn('Select URL types to be cleared for the specified site. If you clear the URLs
                                waiting in the queue, those URLs will not be saved, unless they are collected again. If you
                                clear already-saved URLs, those URLs may end up in the queue again, and they may be saved
                                as posts again. So, you may want to delete the posts as well, unless you want duplicate content.'),
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                    <td>
                        <?php echo $__env->make('form-items/select', [
                            'name'      =>  '_kdn_tools_url_type',
                            'options'   =>  $urlTypes,
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                </tr>

                
                <tr>
                    <td>
                        <?php echo $__env->make('form-items/label', [
                            'for'   =>  '_kdn_tools_safety_check',
                            'title' =>  _kdn("I'm sure"),
                            'info'  =>  _kdn('Check this to indicate that you are sure about this.'),
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                    <td>
                        <?php echo $__env->make('form-items/checkbox', [
                            'name'      =>  '_kdn_tools_safety_check',
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                </tr>
            </table>

            <?php echo $__env->make('form-items/submit-button', [
                'text'  =>  _kdn('Delete URLs')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </form>
<?php $__env->stopSection(true); ?>
<?php echo $__env->make('tools.base.tool-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>