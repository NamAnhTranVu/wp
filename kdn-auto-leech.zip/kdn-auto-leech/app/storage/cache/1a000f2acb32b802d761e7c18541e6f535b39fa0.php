<?php $__env->startSection('title'); ?>
    <?php echo e(_kdn('Manually recrawl (update) a post')); ?>

<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <form action="" class="tool-form">
        

        <?php echo $__env->make('partials.form-nonce-and-action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <input type="hidden" name="tool_type" value="recrawl_post">

        <div class="panel-wrap kdn-settings-meta-box">

            <table class="kdn-settings">
                
                <tr>
                    <td>
                        <?php echo $__env->make('form-items/label', [
                            'for'   =>  '_kdn_tools_recrawl_post_id',
                            'title' =>  _kdn('Post ID'),
                            'info'  =>  _kdn('Write the ID of the post you want to update.'),
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                    <td>
                        <?php echo $__env->make('form-items/text', [
                            'name'          =>  '_kdn_tools_recrawl_post_id',
                            'type'          =>  'text',
                            'min'           =>  0,
                            'placeholder'   => _kdn('Post ID...')
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                </tr>

            </table>

            <?php echo $__env->make('form-items/submit-button', [
                'text'  =>  _kdn('Recrawl')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="recrawl-count">
                <span class="label-count"><?php echo e(_kdn('Recrawling:')); ?></span> <span class="processed">0</span> / <span class="count">0</span> -
                <span class="label-times"><?php echo e(_kdn('Run count:')); ?></span> <span class="times">0</span> -
                <span class="label-total"><?php echo e(_kdn('Total:')); ?></span> <span class="total">0</span>
            </div>

            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </form>
<?php $__env->stopSection(true); ?>
<?php echo $__env->make('tools.base.tool-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>