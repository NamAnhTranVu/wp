<?php if(isset($isResponseFromCache) && $isResponseFromCache): ?>
    <div class="from-cache">
        <span><?php echo e(_kdn("Response retrieved from cache.")); ?></span>

        
        <?php if(isset($testUrl) && $testUrl): ?>
            <span>
                <a role="button" class="invalidate-cache-for-this-url" data-url="<?php echo e($testUrl); ?>" title="<?php echo e(_kdn("Invalidate cache for this URL")); ?>"><?php echo e(_kdn("Invalidate")); ?></a>
            </span>
            <span>
                <a role="button" class="invalidate-all-test-url-caches" data-url="<?php echo e($testUrl); ?>" title="<?php echo e(_kdn("Invalidate all test URL caches")); ?>"><?php echo e(_kdn("Invalidate all")); ?></a>
            </span>
        <?php endif; ?>
    </div>
<?php endif; ?>