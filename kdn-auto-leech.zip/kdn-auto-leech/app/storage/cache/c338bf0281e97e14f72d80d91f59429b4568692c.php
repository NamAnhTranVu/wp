

<?php
    $isRecrawl = false;
    $isRecrawl = isset($type) && $type && $type != 'crawl' ? true : false;
    $now = strtotime(current_time('mysql'));
?>


<table class="section-table <?php echo e(isset($tableClass) && $tableClass ? $tableClass : ''); ?>">

    
    <thead>
        <tr>
            <th><?php echo e(_kdn("Post")); ?></th>
            <th><?php echo e($isRecrawl ? _kdn("Recrawled") : _kdn("Saved")); ?></th>
            <?php if($isRecrawl): ?>
                <th class="col-update-count"><?php echo e(_kdn("Update Count")); ?></th>
            <?php endif; ?>
        </tr>
    </thead>

    
    <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!isset($post->kdn) || !isset($post->kdn->site)): ?> <?php continue; ?> <?php endif; ?>
            <tr>
                
                <td class="col-post">
                    
                    <div class="post-title">
                        <a href="<?php echo get_permalink($post->ID); ?>" target="_blank">
                            <?php echo e($post->post_title); ?>

                        </a>

                        
                        <span class="edit-link">
                            - <a href="<?php echo get_edit_post_link($post->ID); ?>" target="_blank">
                                <?php echo e(_kdn("Edit")); ?>

                            </a>
                        </span>
                    </div>

                    
                    <div class="post-details">
                        
                        <?php echo $__env->make('dashboard.partials.site-link', ['site' => $post->kdn->site], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        
                        <span class="post-type">
                            (<?php echo e($post->post_type); ?>)
                        </span>

                        
                        <span class="id">
                            <?php echo e(_kdn("ID")); ?>: <?php echo e($post->ID); ?>

                        </span> -

                        
                        <span class="target-url">
                            <a href="<?php echo $post->kdn->url; ?>" target="_blank">
                                <?php echo mb_strlen($post->kdn->url) > 255 ? mb_substr($post->kdn->url, 0, 255) . "..." : $post->kdn->url; ?>

                            </a>
                        </span>
                    </div>

                </td>

                
                <td class="col-date">
                    
                    <span class="diff-for-humans">
                        <?php
                            $timestamp = strtotime($isRecrawl ? $post->kdn->recrawled_at : $post->kdn->saved_at);
                        ?>
                        <?php echo e(\KDNAutoLeech\Utils::getDiffForHumans($timestamp)); ?>

                        <?php echo e($timestamp > $now ? _kdn("later") : _kdn("ago")); ?>

                    </span>

                    <span class="date">
                        (<?php echo e(\KDNAutoLeech\Utils::getDateFormatted($isRecrawl ? $post->kdn->recrawled_at : $post->kdn->saved_at)); ?>)
                    </span>
                </td>

                
                <?php if($isRecrawl): ?>
                    <td class="col-update-count">
                        <?php echo e($post->kdn->update_count); ?>

                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>