<?php

$isLanguagesAvailableGoogle = $languagesGoogleTranslateFrom && $languagesGoogleTranslateTo;
$optionsLoadLanguagesButtonGoogle = [
    'class'                 => 'google',
    'isLanguagesAvailable'  => $isLanguagesAvailableGoogle,
    'data' => [
        'selectors' => [
            'project_id' => '#_kdn_translation_google_translate_project_id',
            'api_key'    => '#_kdn_translation_google_translate_api_key',
        ],
        'serviceType' => \KDNAutoLeech\Objects\Translation\TextTranslator::KEY_GOOGLE_CLOUD_TRANSLATION,
        'requestType' => 'load_refresh_translation_languages',
    ],
];

$isLanguagesAvailableMicrosoft = $languagesMicrosoftTranslatorTextFrom && $languagesMicrosoftTranslatorTextTo;
$optionsLoadLanguagesButtonMicrosoft = [
    'class'                 => 'microsoft',
    'isLanguagesAvailable'  => $isLanguagesAvailableMicrosoft,
    'data' => [
        'selectors' => [
            'client_secret' => '#_kdn_translation_microsoft_translate_client_secret',
        ],
        'serviceType' => \KDNAutoLeech\Objects\Translation\TextTranslator::KEY_MICROSOFT_TRANSLATOR_TEXT,
        'requestType' => 'load_refresh_translation_languages',
    ],
];

$isLanguagesAvailableYandex = $languagesYandexTranslatorFrom && $languagesYandexTranslatorTo;
$optionsLoadLanguagesButtonYandex = [
    'class'                 => 'yandex',
    'isLanguagesAvailable'  => $isLanguagesAvailableYandex,
    'data' => [
        'selectors' => [
            'api' => 'input[name*="_translation_yandex_translate_api"]',
        ],
        'serviceType' => \KDNAutoLeech\Objects\Translation\TextTranslator::KEY_YANDEX_TRANSLATOR,
        'requestType' => 'load_refresh_translation_languages',
    ],
];

$optionsRefreshLanguagesLabel = [
    'title' => _kdn('Refresh languages'),
    'info'  => _kdn('Refresh languages by retrieving them from the API. By this way, if there are new languages, you can get them.')
];

$videoUrlGoogleCloudTranslationAPI  = 'https://kdnautoleech.com/kien-thuc';
$videoUrlMicrosoftTranslatorTextAPI = 'https://kdnautoleech.com/kien-thuc';
$videoUrlYandexTranslatorAPI        = 'https://kdnautoleech.com/kien-thuc';

?>

<div class="kdn-settings-title">
    <h3><?php echo e(_kdn('Translation')); ?></h3>
    <span><?php echo e(_kdn('Set content translation options')); ?></span>
</div>

<table class="kdn-settings">

    <?php if($isGeneralPage): ?>
        
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', [
                    'for'   =>  '_kdn_is_translation_active',
                    'title' =>  _kdn('Translation is active?'),
                    'info'  =>  _kdn('If you want to activate automated content translation, check this. Note that
                            translating will increase the time required to crawl a post.')
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/checkbox', [
                    'name' => '_kdn_is_translation_active',
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_selected_translation_service',
                'title' =>  _kdn('Translate with'),
                'info'  =>  _kdn('Select the translation service you want to use to translate contents. You also need
                    to properly configure the settings of the selected API below.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/select', [
                'name'      =>  '_kdn_selected_translation_service',
                'options'   =>  $translationServices,
                'isOption'  =>  $isOption,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <?php echo $__env->make('partials.table-section-title', ['title' => _kdn("Google Cloud Translation Options")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_google_translate_from',
                'title' =>  _kdn('Translate from'),
                'info'  =>  _kdn('Select the language of the content of crawled posts.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableGoogle): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_google_translate_from',
                    'options'   =>  $languagesGoogleTranslateFrom,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonGoogle + ['id' => '_kdn_translation_google_translate_from'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_google_translate_to',
                'title' =>  _kdn('Translate to'),
                'info'  =>  _kdn('Select the language to which the content should be translated.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td class="double-translate">
            <?php if($isLanguagesAvailableGoogle): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_google_translate_to',
                    'options'   =>  $languagesGoogleTranslateTo,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="input-group double-between dashicons dashicons-arrow-right-alt"></div>

                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_google_translate_end',
                    'options'   =>  array_merge(['' => _kdn('None')], $languagesGoogleTranslateTo),
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonGoogle + ['id' => '_kdn_translation_google_translate_to'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <?php if($isLanguagesAvailableGoogle): ?>
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', $optionsRefreshLanguagesLabel, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonGoogle, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_google_translate_project_id',
                'title' =>  _kdn('Project ID'),
                'info'  =>  _kdn('Project ID retrieved from Google Cloud Console.') . ' ' . _kdn_trans_how_to_get_it($videoUrlGoogleCloudTranslationAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name' => '_kdn_translation_google_translate_project_id',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_google_translate_api_key',
                'title' =>  _kdn('API Key'),
                'info'  =>  _kdn('API key retrieved from Google Cloud Console.') . ' ' . _kdn_trans_how_to_get_it($videoUrlGoogleCloudTranslationAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name' => '_kdn_translation_google_translate_api_key',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_google_translate_test',
                'title' =>  _kdn('Test Google Translate Options'),
                'info'  =>  _kdn('You can write any text to test Google Translate options you configured.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_kdn_translation_google_translate_test',
                'placeholder'   =>  _kdn('Test text to translate...'),
                'rows'          =>  3,
                'data'          =>  [
                    'apiKeySelector'    => '#_kdn_translation_google_translate_api_key',
                    'projectIdSelector' => '#_kdn_translation_google_translate_project_id',
                    'fromSelector'      => '#_kdn_translation_google_translate_from',
                    'toSelector'        => '#_kdn_translation_google_translate_to',
                    'endSelector'       => '#_kdn_translation_google_translate_end',
                    'testType'          =>  \KDNAutoLeech\Test\Test::$TEST_TYPE_TRANSLATION,
                    'serviceType'       =>  \KDNAutoLeech\Objects\Translation\TextTranslator::KEY_GOOGLE_CLOUD_TRANSLATION,
                    'requiredSelectors' =>  "#_kdn_translation_google_translate_test & #_kdn_translation_google_translate_api_key & #_kdn_translation_google_translate_project_id & #_kdn_translation_google_translate_from & #_kdn_translation_google_translate_to"
                ],
                'addon'         =>  'dashicons dashicons-search',
                'test'          =>  true,
                'addonClasses'  => 'kdn-test-translation google-translate',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <?php echo $__env->make('partials.table-section-title', ['title' => _kdn("Microsoft Translator Text Options")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_microsoft_translate_from',
                'title' =>  _kdn('Translate from'),
                'info'  =>  _kdn('Select the language of the content of crawled posts.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableMicrosoft): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      => '_kdn_translation_microsoft_translate_from',
                    'options'   => $languagesMicrosoftTranslatorTextFrom,
                    'isOption'  => $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonMicrosoft + ['id' => '_kdn_translation_microsoft_translate_from'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_microsoft_translate_to',
                'title' =>  _kdn('Translate to'),
                'info'  =>  _kdn('Select the language to which the content should be translated.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td class="double-translate">
            <?php if($isLanguagesAvailableMicrosoft): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_microsoft_translate_to',
                    'options'   =>  $languagesMicrosoftTranslatorTextTo,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="input-group double-between dashicons dashicons-arrow-right-alt"></div>

                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_microsoft_translate_end',
                    'options'   =>  array_merge(['' => _kdn('None')], $languagesMicrosoftTranslatorTextTo),
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonMicrosoft + ['id' => '_kdn_translation_microsoft_translate_to'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <?php if($isLanguagesAvailableMicrosoft): ?>
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', $optionsRefreshLanguagesLabel, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonMicrosoft, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_microsoft_translate_client_secret',
                'title' =>  _kdn('Client Secret'),
                'info'  =>  _kdn('Client secret retrieved from Microsoft Azure Portal.') . ' ' . _kdn_trans_how_to_get_it($videoUrlMicrosoftTranslatorTextAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name' => '_kdn_translation_microsoft_translate_client_secret',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_microsoft_translate_test',
                'title' =>  _kdn('Test Microsoft Translator Text Options'),
                'info'  =>  _kdn('You can write any text to test Microsoft Translator Text options you configured.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_kdn_translation_microsoft_translate_test',
                'placeholder'   =>  _kdn('Test text to translate...'),
                'rows'          =>  3,
                'data'          =>  [
                    'clientSecretSelector'  => '#_kdn_translation_microsoft_translate_client_secret',
                    'fromSelector'          => '#_kdn_translation_microsoft_translate_from',
                    'toSelector'            => '#_kdn_translation_microsoft_translate_to',
                    'endSelector'           => '#_kdn_translation_microsoft_translate_end',
                    'testType'              =>  \KDNAutoLeech\Test\Test::$TEST_TYPE_TRANSLATION,
                    'serviceType'           =>  \KDNAutoLeech\Objects\Translation\TextTranslator::KEY_MICROSOFT_TRANSLATOR_TEXT,
                    'requiredSelectors'     =>  "#_kdn_translation_microsoft_translate_test & #_kdn_translation_microsoft_translate_client_secret & #_kdn_translation_microsoft_translate_from & #_kdn_translation_microsoft_translate_to"
                ],
                'addon'         =>  'dashicons dashicons-search',
                'test'          =>  true,
                'addonClasses'  => 'kdn-test-translation microsoft-translator-text',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <?php echo $__env->make('partials.table-section-title', ['title' => _kdn("Yandex Translator Options")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_yandex_translate_from',
                'title' =>  _kdn('Translate from'),
                'info'  =>  _kdn('Select the language of the content of crawled posts.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableYandex): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      => '_kdn_translation_yandex_translate_from',
                    'options'   => $languagesYandexTranslatorFrom,
                    'isOption'  => $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonYandex + ['id' => '_kdn_translation_yandex_translate_from'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_yandex_translate_to',
                'title' =>  _kdn('Translate to'),
                'info'  =>  _kdn('Select the language to which the content should be translated.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td class="double-translate">
            <?php if($isLanguagesAvailableYandex): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_yandex_translate_to',
                    'options'   =>  $languagesYandexTranslatorTo,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="input-group double-between dashicons dashicons-arrow-right-alt"></div>

                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_kdn_translation_yandex_translate_end',
                    'options'   =>  array_merge(['' => _kdn('None')], $languagesYandexTranslatorTo),
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonYandex + [
                    'id' => '_kdn_translation_yandex_translate_to'
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <?php if($isLanguagesAvailableYandex): ?>
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', $optionsRefreshLanguagesLabel, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonYandex, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr id="_multiple_kdn_translation_yandex_translate_api">
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_yandex_translate_api',
                'title' =>  _kdn('API Key'),
                'info'  =>  _kdn('API Key retrieved from Yandex Translator.') . ' ' . _kdn_trans_how_to_get_it($videoUrlYandexTranslatorAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/multiple', [
                'include'       =>  'form-items/text',
                'name'          =>  '_kdn_translation_yandex_translate_api',
                'addKeys'       =>  true,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_yandex_translate_api_randomize',
                'title' =>  _kdn('Randomize API Keys?'),
                'info'  =>  _kdn('When you check this, the API Keys you entered will be randomized. This means, the order of the API Keys will be changed every time before a new request is made. If you do not check this, the API Keys will be tried in the order you entered them.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name' => '_kdn_translation_yandex_translate_api_randomize',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_kdn_translation_yandex_translate_test',
                'title' =>  _kdn('Test Yandex Translator Options'),
                'info'  =>  _kdn('You can write any text to test Yandex Translator options you configured.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_kdn_translation_yandex_translate_test',
                'placeholder'   =>  _kdn('Test text to translate...'),
                'rows'          =>  3,
                'data'          =>  [
                    'apiSelector'           => '#_multiple_kdn_translation_yandex_translate_api',
                    'randomizeSelector'     => '#_kdn_translation_yandex_translate_api_randomize:checked',
                    'fromSelector'          => '#_kdn_translation_yandex_translate_from',
                    'toSelector'            => '#_kdn_translation_yandex_translate_to',
                    'endSelector'           => '#_kdn_translation_yandex_translate_end',
                    'testType'              =>  \KDNAutoLeech\Test\Test::$TEST_TYPE_TRANSLATION,
                    'serviceType'           =>  \KDNAutoLeech\Objects\Translation\TextTranslator::KEY_YANDEX_TRANSLATOR,
                    'requiredSelectors'     =>  "#_kdn_translation_yandex_translate_test & #_kdn_translation_yandex_translate_api & #_kdn_translation_yandex_translate_from & #_kdn_translation_yandex_translate_to"
                ],
                'addon'         =>  'dashicons dashicons-search',
                'test'          =>  true,
                'addonClasses'  => 'kdn-test-translation yandex-translator',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    <?php

    /**
     * Fires before closing table tag in translation tab of general settings page.
     *
     * @param array $settings       Existing settings and their values saved by user before
     * @param bool  $isGeneralPage  True if this is called from a general settings page.
     * @param bool  $isOption       True if this is an option, instead of a setting. A setting is a post meta, while
     *                              an option is a WordPress option. This is true when this is fired from general
     *                              settings page.
     * @since 1.6.3
     */
    do_action('kdn/view/general-settings/tab/translation', $settings, $isGeneralPage, $isOption);

    ?>

</table>