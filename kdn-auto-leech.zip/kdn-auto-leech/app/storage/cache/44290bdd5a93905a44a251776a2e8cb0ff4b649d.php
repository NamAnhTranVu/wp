<div class="input-group selector-custom-shortcode <?php echo e(isset($addon) ? 'addon dev-tools' : ''); ?> <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <?php if(isset($addon)): ?>
        <?php echo $__env->make('form-items.partials.button-addon-test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('form-items.dev-tools.button-dev-tools', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(isset($optionsBox) && $optionsBox): ?>
            <?php echo $__env->make('form-items.options-box.button-options-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <div class="input-container <?php if(isset($ajax) && $ajax): ?> has-ajax <?php endif; ?>">
        <input type="checkbox" name="<?php echo e($name . '[single]'); ?>" id="<?php echo e($name . '[single]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Single?')); ?>"
               <?php if(isset($value['single'])): ?> checked="checked" <?php endif; ?> tabindex="0">

        <?php if(isset($ajax) && $ajax): ?>
          <input type="number" name="<?php echo e($name . '[ajax]'); ?>" id="<?php echo e($name . '[ajax]'); ?>" placeholder="<?php echo e(_kdn('Ajax')); ?>"
                 value="<?php echo e(isset($value['ajax']) ? $value['ajax'] : ''); ?>"
                 class="ajax-selector" tabindex="0">
        <?php endif; ?>

        <input type="text" name="<?php echo e($name . '[selector]'); ?>" id="<?php echo e($name . '[selector]'); ?>" placeholder="<?php echo e(_kdn('Selector')); ?>"
               value="<?php echo e(isset($value['selector']) ? $value['selector'] : ''); ?>"
               class="css-selector" tabindex="0">

        <input type="text" name="<?php echo e($name . '[attr]'); ?>" id="<?php echo e($name . '[attr]'); ?>" placeholder="<?php echo e(sprintf(_kdn('Attribute (default: %s)'), $defaultAttr)); ?>"
               value="<?php echo e(isset($value['attr']) ? $value['attr'] : ''); ?>" class="css-selector-attr" tabindex="0">

        <input type="text" name="<?php echo e($name . '[short_code]'); ?>" id="<?php echo e($name . '[short_code]'); ?>" placeholder="<?php echo e(_kdn('Shortcode without brackets')); ?>"
               value="<?php echo e(isset($value['short_code']) ? $value['short_code'] : ''); ?>" class="short-code" tabindex="0">
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>