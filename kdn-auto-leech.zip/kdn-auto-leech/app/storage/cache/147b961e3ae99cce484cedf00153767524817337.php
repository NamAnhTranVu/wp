<div class="input-container">
    <div class="input-group">

        <button class="button <?php echo e(isset($buttonClass) && $buttonClass ? $buttonClass : ''); ?>"
                type="button"
                title="<?php echo e(isset($title) ? $title : ''); ?>"
                <?php if(isset($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?>
                <?php if(isset($data)): ?> data-kdn="<?php echo e(json_encode($data)); ?>" <?php endif; ?>
        >
            <?php if(isset($iconClass) && $iconClass): ?>
                <span class="<?php echo e($iconClass); ?>"></span>
            <?php endif; ?>
            <?php echo e($text); ?>

        </button>

    </div>
</div>
