<div class="description">
    <?php echo e(_kdn('Import or export options box settings.')); ?>

</div>

<table class="kdn-settings">

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   => '_options_box_import_settings',
                'title' => _kdn('Import Settings'),
                'info'  => _kdn('Paste the settings exported from another options box to import. <b>Current settings
                    will be overridden.</b>')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_options_box_import_settings',
                'placeholder'   =>  _kdn('Paste settings and click the import button. Note: This will override all settings.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('form-items.button', [
                'buttonClass' => 'options-box-import',
                'text' => _kdn("Import")
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   => '_options_box_export_settings',
                'title' => _kdn('Export Settings'),
                'info'  => _kdn('You can copy the settings here and use the copied code to export settings to
                    another options box.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_options_box_export_settings',
                'readOnly'      =>  true,
                'noName'        =>  true,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

</table>