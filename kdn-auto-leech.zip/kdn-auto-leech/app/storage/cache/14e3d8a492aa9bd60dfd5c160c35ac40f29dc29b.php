<?php $__env->startSection('title'); ?>
    <?php echo e(_kdn('Unlock all URLs')); ?>

<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <form action="" class="tool-form">
        <?php echo $__env->make('partials.form-nonce-and-action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <input type="hidden" name="tool_type" value="unlock_all_urls">

        <div class="panel-wrap kdn-settings-meta-box">

            
            <div>
                <p>
                    <?php echo e(_kdn('The plugin locks the URLs which it is processing. This is to avoid processing
                        already-being-processed URLs. But sometimes things go wrong either with your server or the target server
                        and some URLs stay locked. You can see these URLs shown as "currently being crawled/recrawled" in
                        dashboard. If you see some URLs are stuck there and you do not want to see them, you can use this tool
                        to unlock all URLs.')); ?>

                </p>
            </div>

            <?php echo $__env->make('form-items/submit-button', [
                'text'  =>  _kdn('Unlock All URLs')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </form>
<?php $__env->stopSection(true); ?>

<?php echo $__env->make('tools.base.tool-container', [
    'noToggleButton' => true
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>