<div class="description">
    <?php echo e(_kdn("Find and replace in each item. These options will be applied before any changes are made to the current item.")); ?> <?php echo _kdn_trans_regex(); ?>

</div>

<table class="kdn-settings">
    <tr>
        <td>
            <?php echo $__env->make('form-items/multiple', [
                'include'       =>  'form-items/find-replace',
                'name'          =>  '_options_box[find_replace]',
                'addKeys'       =>  true,
                'remove'        =>  true,
                'addon'         =>  'dashicons dashicons-search',
                'data'          =>  [
                    'testType'  =>  \KDNAutoLeech\Test\Test::$TEST_TYPE_FIND_REPLACE,
                    'extra'     =>  $dataExtra
                ],
                'test'          => true,
                'addonClasses'  => 'kdn-test-find-replace'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
    </tr>

</table>