<button
        class="button kdn-addon <?php echo e(isset($test) ? 'kdn-test' : ''); ?> <?php echo e(isset($addonClasses) ? $addonClasses : ''); ?>"
        title="<?php echo e(isset($addonTitle) ? $addonTitle : _kdn('Test')); ?>"
        <?php if(isset($data)): ?> data-kdn="<?php echo e(json_encode($data)); ?>" <?php endif; ?>
>
    <span class="<?php echo e($addon); ?>"></span>
</button>