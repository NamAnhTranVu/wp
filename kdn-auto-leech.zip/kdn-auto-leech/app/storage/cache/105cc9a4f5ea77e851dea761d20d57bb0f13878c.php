

<?php
    $nameExists = $siteName !== null;
    $testData = [
        'testKey' => $testKey,
        'siteId'  => $siteId,
        'testUrl' => $testUrl,
        'exists'  => $nameExists
    ];
?>

<tr class="test-history-item" data-test="<?php echo e(json_encode($testData)); ?>">
    <td class="controls-leading">
        <?php echo $__env->make('form-items.partials.button-addon-test', [
            'addon' =>  'dashicons dashicons-search',
            'test'  => true,
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </td>
    <td><?php echo e($number); ?></td>
    <td class="site-name">
        <?php if($nameExists): ?>
            <a href="<?php echo get_edit_post_link($siteId); ?>" target="_blank">
                <?php echo e($siteName); ?>

            </a>
        <?php else: ?>
            <?php echo e(_kdn('Not found')); ?>

        <?php endif; ?>
    </td>
    <td class="test-type">
        <?php echo e($testName); ?>

    </td>
    <td class="test-url">
        <a href="<?php echo e($testUrl); ?>" target="_blank"><?php echo e($testUrl); ?></a>
    </td>
    <td class="controls-trailing">
        <?php echo $__env->make('form-items.remove-button', [
            'disableSort' => true
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </td>
</tr>