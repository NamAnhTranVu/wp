<div class="input-group custom-post-meta <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <div class="input-container">
        <input type="checkbox" name="<?php echo e($name . '[multiple]'); ?>" id="<?php echo e($name . '[multiple]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Multiple?')); ?>"
               <?php if(isset($value['multiple'])): ?> checked="checked" <?php endif; ?> tabindex="0">

        <input type="checkbox" name="<?php echo e($name . '[json]'); ?>" id="<?php echo e($name . '[json]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('JSON Parse?')); ?>"
               <?php if(isset($value['json'])): ?> checked="checked" <?php endif; ?> tabindex="0">

        <input type="text" name="<?php echo e($name . '[key]'); ?>" id="<?php echo e($name . '[key]'); ?>" placeholder="<?php echo e(_kdn('Post meta key')); ?>"
               value="<?php echo e(isset($value['key']) ? $value['key'] : ''); ?>" class="meta-key" tabindex="0">

        <textarea name="<?php echo e($name . '[value]'); ?>" id="<?php echo e($name . '[value]'); ?>" placeholder="<?php echo e(_kdn('Meta value')); ?>" tabindex="0"><?php echo e(isset($value['value']) ? $value['value'] : ''); ?></textarea>
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>