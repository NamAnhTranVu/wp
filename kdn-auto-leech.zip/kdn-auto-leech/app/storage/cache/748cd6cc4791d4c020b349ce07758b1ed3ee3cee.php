<button role="button" class="button toggle"><?php echo e($toggleText); ?></button>

<div class="toggleable <?php if(isset($hidden) && $hidden): ?> hidden <?php endif; ?>" id="<?php echo e($id); ?>">
    <div class="section-title">
        <?php echo e($title); ?>

    </div>

    <textarea class="data" rows="16"><?php echo e($content); ?></textarea>
</div>