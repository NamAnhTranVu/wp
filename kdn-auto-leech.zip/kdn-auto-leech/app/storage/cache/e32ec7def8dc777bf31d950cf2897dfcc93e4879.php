<div class="input-group post-and-image-url <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>

    <div class="input-container">
        <input type="text" name="<?php echo e($name . '[postUrl]'); ?>" id="<?php echo e($name . '[postUrl]'); ?>" placeholder="<?php echo e(_kdn('Post URL...')); ?>"
               value="<?php echo e(isset($value['postUrl']) ? $value['postUrl'] : ''); ?>"
               class="post-url"
                tabindex="0">

        <input type="text" name="<?php echo e($name . '[imageUrl]'); ?>" id="<?php echo e($name . '[imageUrl]'); ?>" placeholder="<?php echo e(_kdn('Featured image URL...')); ?>"
               value="<?php echo e(isset($value['imageUrl']) ? $value['imageUrl'] : ''); ?>"
               class="image-url"
                tabindex="0">
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>