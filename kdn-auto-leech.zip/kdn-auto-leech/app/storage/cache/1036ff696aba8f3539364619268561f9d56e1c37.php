<?php if(isset($urls) && $urls): ?>
    <h3><?php echo e(_kdn('Post URLs')); ?></h3>
    <?php echo $__env->make('site-tester/urls-with-test', [
        'urls'      =>  $urls,
        'testType'  =>  'test_post'
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if(isset($nextPageUrl) && $nextPageUrl): ?>
    <h3><?php echo e(_kdn('Next Page URL')); ?></h3>
    <div>
        <?php echo $__env->make('site-tester/button-test-this', ['url' => $nextPageUrl, 'type' => 'test_category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <a target="_blank" href="<?php echo e($nextPageUrl); ?>"><?php echo e($nextPageUrl); ?></a>
    </div>
<?php endif; ?>