<div class="wrap container-tools kdn-settings-meta-box" id="container-tools">
    <h1><?php echo e(_kdn('Tools')); ?></h1>

    
    <h2 class="nav-tab-wrapper">
        <a href="#" data-tab="#tab-manual-crawling"     class="nav-tab nav-tab-active"><?php echo e(_kdn('Manual Crawling')); ?></a>
        <a href="#" data-tab="#tab-manual-recrawling"   class="nav-tab"><?php echo e(_kdn('Manual Recrawling')); ?></a>
        <a href="#" data-tab="#tab-urls"                class="nav-tab"><?php echo e(_kdn('URLs')); ?></a>

        <?php echo $__env->make('partials.input-url-hash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </h2>

    
    <div id="tab-manual-crawling" class="tab">
        <?php echo $__env->make('tools/tabs/tab-manual-crawling', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php

        /**
         * Fires at the end of closing tag of the content area in Tools page
         *
         * @since 1.6.3
         */
        do_action('kdn/view/tools');

        ?>
    </div>

    
    <div id="tab-manual-recrawling" class="tab hidden">
        <?php echo $__env->make('tools/tabs/tab-manual-recrawling', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    
    <div id="tab-urls" class="tab hidden">
        <?php echo $__env->make('tools/tabs/tab-urls', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

</div>