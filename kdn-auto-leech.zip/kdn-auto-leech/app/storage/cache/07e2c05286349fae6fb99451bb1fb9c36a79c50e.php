<div class="input-group custom-post-method <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <div class="input-container <?php if(isset($regex)): ?> has-regex <?php endif; ?>">

        <?php if(isset($regex)): ?>
          <input type="checkbox" name="<?php echo e($name . '[regex]'); ?>" id="<?php echo e($name . '[regex]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Regex?')); ?>"
                 <?php if(isset($value['regex'])): ?> checked="checked" <?php endif; ?> tabindex="0">
        <?php endif; ?>

        <?php if(isset($negate)): ?>
          <input type="checkbox" name="<?php echo e($name . '[negate]'); ?>" id="<?php echo e($name . '[negate]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Negate?')); ?>"
                 <?php if(isset($value['negate'])): ?> checked="checked" <?php endif; ?> tabindex="0">
        <?php endif; ?>

        <input type="text"
               name="<?php echo e($name . '[parse]'); ?>"
               id="<?php echo e($name . '[parse]'); ?>"
               placeholder="<?php echo e(_kdn('Started parameter')); ?>"
               value="<?php echo e(isset($value['parse']) ? $value['parse'] : ''); ?>" class="parse" tabindex="0">

        <input type="text"
               name="<?php echo e($name . '[method]'); ?>"
               id="<?php echo e($name . '[method]'); ?>"
               placeholder="<?php echo e(isset($placeholder1) ? _kdn($placeholder1) : ''); ?>"
               value="<?php echo e(isset($value['method']) ? $value['method'] : ''); ?>" class="method" tabindex="0">

        <input type="text"
               name="<?php echo e($name . '[matches]'); ?>"
               id="<?php echo e($name . '[matches]'); ?>"
               placeholder="<?php echo e(isset($placeholder2) ? _kdn($placeholder2) : ''); ?>"
               value="<?php echo e(isset($value['matches']) ? $value['matches'] : ''); ?>" tabindex="0">
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>