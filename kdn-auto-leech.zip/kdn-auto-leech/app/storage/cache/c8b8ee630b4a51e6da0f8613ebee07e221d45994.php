<div class="input-group selector-attribute-assign <?php echo e(isset($addon) ? 'addon dev-tools' : ''); ?> <?php echo e(isset($remove) ? 'remove' : ''); ?> <?php echo e(isset($assign) ? $assign : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <?php if(isset($addon)): ?>
        <?php echo $__env->make('form-items.partials.button-addon-test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('form-items.dev-tools.button-dev-tools', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(isset($optionsBox) && $optionsBox): ?>
            <?php echo $__env->make('form-items.options-box.button-options-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <div class="input-container <?php if(isset($ajax) && $ajax): ?> has-ajax <?php endif; ?> <?php if(isset($regex) && $regex): ?> has-regex <?php endif; ?>">
        <?php if(isset($regex) && $regex): ?>
        <input type="checkbox" name="<?php echo e($name . '[regex]'); ?>" id="<?php echo e($name . '[regex]'); ?>" data-toggle="tooltip" title="<?php echo e(_kdn('Regex?')); ?>"
            <?php if(isset($value['regex'])): ?> checked="checked" <?php endif; ?> tabindex="0">
        <?php endif; ?>

        <?php if(isset($ajax) && $ajax): ?>
          <input type="number" name="<?php echo e($name . '[ajax]'); ?>" id="<?php echo e($name . '[ajax]'); ?>" placeholder="<?php echo e(_kdn('Ajax')); ?>"
                 value="<?php echo e(isset($value['ajax']) ? $value['ajax'] : ''); ?>"
                 class="ajax-selector" tabindex="0">
        <?php endif; ?>

        <input type="text" name="<?php echo e($name . '[selector]'); ?>" id="<?php echo e($name . '[selector]'); ?>" placeholder="<?php echo e(_kdn('Selector')); ?>"
               value="<?php echo e(isset($value['selector']) ? $value['selector'] : ''); ?>"
               class="css-selector" tabindex="0">

        <input type="text" name="<?php echo e($name . '[attr]'); ?>" id="<?php echo e($name . '[attr]'); ?>" placeholder="<?php echo e(sprintf(_kdn('Attribute (default: %s)'), $defaultAttr)); ?>"
               value="<?php echo e(isset($value['attr']) ? $value['attr'] : ''); ?>" class="css-selector-attr" tabindex="0">

        <?php if(isset($assign) && $assign): ?>
        <input type="text" name="<?php echo e($name . '[' . $assign . ']'); ?>" id="<?php echo e($name . '[' . $assign . ']'); ?>" <?php if(isset($valuePlaceholder) && $valuePlaceholder): ?> placeholder="<?php echo e(_kdn($valuePlaceholder)); ?>" <?php endif; ?>
               value="<?php echo e(isset($value[$assign]) ? $value[$assign] : ''); ?>" class="<?php echo e($assign); ?>" tabindex="0">
        <?php endif; ?>
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>