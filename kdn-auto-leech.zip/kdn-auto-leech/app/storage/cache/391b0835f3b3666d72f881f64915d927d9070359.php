<button class="button kdn-remove" title="<?php echo e(_kdn("Remove")); ?>"><span class="dashicons dashicons-trash"></span></button>

<?php if(!isset($disableSort) || !$disableSort): ?>
    <div class="kdn-sort"><span class="dashicons dashicons-move"></span></div>
<?php endif; ?>