<?php $__env->startSection('content-class'); ?> <?php $__env->stopSection(true); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('dashboard.partials.select-table-item-count', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(true); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <?php if(!empty($urls)): ?>
        <?php echo $__env->make('dashboard.partials.table-urls', [
            'urls'              => $urls,
            'fieldName'         => $fieldName,
            'dateColumnName'    => $dateColumnName,
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php else: ?>

        <?php echo e(_kdn("No URLs.")); ?>


    <?php endif; ?>

<?php $__env->stopSection(true); ?>
<?php echo $__env->make('dashboard.partials.section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>