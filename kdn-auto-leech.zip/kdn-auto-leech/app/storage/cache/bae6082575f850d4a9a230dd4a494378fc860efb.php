<div class="kdn-settings-title">
    <h3><?php echo e(_kdn('Notes')); ?></h3>
    <span><?php echo e(_kdn('You can write your notes about this site here. It is just for you to keep notes.')); ?></span>
</div>

<table class="kdn-settings">
    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   => '_notes',
                'title' => _kdn('Notes'),
                'info'  => _kdn('Write anything...')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td><?php echo $__env->make('form-items/template-editor', ['name' => '_notes', 'height' => 450], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
    </tr>

    <?php

    /**
     * Fires before closing table tag in notes tab of site settings page.
     *
     * @param array $settings   Existing settings and their values saved by user before
     * @param int $postId       ID of the site
     * @since 1.6.3
     */
    do_action('kdn/view/site-settings/tab/notes', $settings, $postId);

    ?>
</table>