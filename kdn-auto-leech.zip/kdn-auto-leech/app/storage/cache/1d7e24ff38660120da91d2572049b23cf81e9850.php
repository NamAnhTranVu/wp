<div class="description">
    <?php echo _kdn("Find and replace in <b>each saved file's name</b>. These options will be applied after the file is saved
    and before any changes are made to the current item."); ?>

    <?php echo _kdn_trans_regex(); ?>

    <?php echo _kdn_file_options_box_tests_note(); ?>

</div>

<table class="kdn-settings">
    <tr>
        <td>
            <?php echo $__env->make('form-items/multiple', [
                'include'       =>  'form-items/find-replace',
                'name'          =>  '_options_box[file_find_replace]',
                'addKeys'       =>  true,
                'remove'        =>  true,
                'addon'         =>  'dashicons dashicons-search',
                'data'          =>  [
                    'testType'  =>  \KDNAutoLeech\Test\Test::$TEST_TYPE_FILE_FIND_REPLACE,
                    'extra'     =>  $dataExtra
                ],
                'test'          => true,
                'addonClasses'  => 'kdn-test-find-replace'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
    </tr>

</table>