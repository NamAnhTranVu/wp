<div id="kdn-alert" class="notice notice-error hidden">
    <p><?php echo e(_kdn('Please fix the errors.')); ?></p>
</div>