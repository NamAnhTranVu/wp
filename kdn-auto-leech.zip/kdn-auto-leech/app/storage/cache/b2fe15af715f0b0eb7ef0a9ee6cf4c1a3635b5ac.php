<tr class="section-title-container">
    <td colspan="2">
        <div class="section-title">
            <?php echo e($title); ?>

        </div>
    </td>
</tr>