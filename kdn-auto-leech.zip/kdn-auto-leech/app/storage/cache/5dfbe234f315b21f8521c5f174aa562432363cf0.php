<div class="test-results hidden">
    <button class="button hide-test-results"><?php echo e(_kdn('Hide')); ?></button>
    <div class="content"></div>
    <button class="button hide-test-results"><?php echo e(_kdn('Hide')); ?></button>
</div>