<div class="description">
    <?php echo e(_kdn('General options. Before applying the options here, the options defined in the find-replace tab will be applied.')); ?>

</div>

<table class="kdn-settings">

    
    <tr id="options-box-translation">
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_options_box[active_translation]',
                'title' =>  _kdn('Translate?'),
                'info'  =>  _kdn('If you check this, each item will be tried to be translate.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'  => '_options_box[active_translation]'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_options_box[treat_as_json]',
                'title' =>  _kdn('Treat as JSON?'),
                'info'  =>  sprintf(_kdn('If you check this, each item will be tried to be parsed to JSON. You can then
                        use the values from the JSON using <b>[%1$s]</b> short code. When you check this, the item will be
                        removed if it is not a valid JSON.'), \KDNAutoLeech\Objects\Enums\ShortCodeName::KDN_ITEM) . ' ' . _kdn_kdn_item_short_code_dot_key_for_json()
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'  => '_options_box[treat_as_json]'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

</table>