
<div id="message" class="notice notice-<?php echo e(isset($type) ? $type : 'info'); ?> is-dismissible">
    <p><?php echo e(isset($message) ? $message : 'Done.'); ?></p>
    <button type="button" class="notice-dismiss">
        <span class="screen-reader-text"><?php echo e(_kdn('Dismiss this notice.')); ?></span>
    </button>
</div>