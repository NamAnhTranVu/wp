<div class="details" <?php if(isset($id) && $id): ?> id="<?php echo e($id); ?>" <?php endif; ?>>
    <h2>
        <span><?php echo $__env->yieldContent('title'); ?></span>

        <?php if(!isset($noToggleButton) || !$noToggleButton): ?>
            <?php echo $__env->make('partials.button-toggle-info-texts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </h2>
    <div class="inside">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>