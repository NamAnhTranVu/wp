<?php

namespace KDNAutoLeech\Objects\Enums;


class InformationType extends EnumBase {

    const ERROR = 'error';
    const INFO  = 'info';

}