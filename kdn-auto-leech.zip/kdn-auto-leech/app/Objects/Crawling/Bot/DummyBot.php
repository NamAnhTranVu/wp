<?php

namespace KDNAutoLeech\Objects\Crawling\Bot;


class DummyBot extends AbstractBot {

	public function getUrl(){
		return null;
	}

}