<?php

namespace KDNAutoLeech\Objects\Crawling\Preparers\Interfaces;


interface Preparer {

    /**
     * Prepare.
     *
     * @return mixed
     */
    public function prepare();

}