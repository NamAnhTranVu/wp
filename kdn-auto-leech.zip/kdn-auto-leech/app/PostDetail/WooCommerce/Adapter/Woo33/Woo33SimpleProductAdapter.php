<?php

namespace KDNAutoLeech\PostDetail\WooCommerce\Adapter\Woo33;


use KDNAutoLeech\PostDetail\WooCommerce\Adapter\Interfaces\SimpleProductAdapter;

class Woo33SimpleProductAdapter extends Woo33ProductAdapter implements SimpleProductAdapter {

}