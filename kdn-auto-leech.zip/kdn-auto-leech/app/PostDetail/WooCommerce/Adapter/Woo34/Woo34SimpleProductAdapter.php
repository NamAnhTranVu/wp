<?php

namespace KDNAutoLeech\PostDetail\WooCommerce\Adapter\Woo34;


use KDNAutoLeech\PostDetail\WooCommerce\Adapter\Interfaces\SimpleProductAdapter;

class Woo34SimpleProductAdapter extends Woo34ProductAdapter implements SimpleProductAdapter {

}