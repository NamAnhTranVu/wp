<?php

namespace KDNAutoLeech\PostDetail\WooCommerce\Adapter\Woo35;


use KDNAutoLeech\PostDetail\WooCommerce\Adapter\Interfaces\SimpleProductAdapter;

class Woo35SimpleProductAdapter extends Woo35ProductAdapter implements SimpleProductAdapter {

}