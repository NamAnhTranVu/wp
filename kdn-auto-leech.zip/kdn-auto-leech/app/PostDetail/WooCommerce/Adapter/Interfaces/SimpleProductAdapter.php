<?php

namespace KDNAutoLeech\PostDetail\WooCommerce\Adapter\Interfaces;


interface SimpleProductAdapter extends ProductAdapter {

}