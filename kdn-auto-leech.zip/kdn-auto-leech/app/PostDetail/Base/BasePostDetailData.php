<?php

namespace KDNAutoLeech\PostDetail\Base;


abstract class BasePostDetailData {

}