<?php
namespace KDNAutoLeech\Extensions\Translation\yandex\translateapi\src;

/**
 * Exception
 * @author Nikita Gusakov <dev@nkt.me>
 */
class Exception extends \Exception
{

} 
