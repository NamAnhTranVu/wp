import {Tools} from "./app/Tools";

// Initialize when document is ready
jQuery(function($) {
    // Initialize the tools
    new Tools();
});