export enum CrawlingType {
    CRAWL_NOW,
    ADD_TO_DATABASE
}