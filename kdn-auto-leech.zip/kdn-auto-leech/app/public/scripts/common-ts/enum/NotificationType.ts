export enum NotificationType {
    WARN = 'warn',
    INFO = 'info',
    ERROR = 'error',
    SUCCESS = 'success'
}