import {OptionsBox} from "./app/OptionsBox";

jQuery(function($) {
    // Init the options box.
    OptionsBox.getInstance();
});
