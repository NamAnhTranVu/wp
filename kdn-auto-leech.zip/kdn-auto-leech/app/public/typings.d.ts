interface JQuery {
    serializeObjectNoNull: any;
    tooltip: any;
    notify: any;
    sortable: any;
}

interface JQueryStatic {
    featherlight: any;
    notify: any;
}

interface KDN_POST_SETTINGS {
    prepareTestData: any;
    addSettingsToAjaxData: any;
}

interface Window {
    ajaxurl: string;
    pageActionKey: string;
    KDN_POST_SETTINGS: KDN_POST_SETTINGS;
    kdn: any;
    OptimalSelect: any;
    Clipboard: any;
    jQuery: any;
    optionsBox: any;
    $lastClickedOptionsBoxButton: any;
    tinymce: any;
    tinyMCE: any;
}