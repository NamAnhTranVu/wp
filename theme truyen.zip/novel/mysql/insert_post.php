<?php
include 'func.php';
insert_post(
	$data = array(
		'title' => 'hihi',
		'content' => 'dmmm',
		'post_status'=> 'publish',
		'category' =>array('ok'),
		'author'  => array('ok'),
		'thumb'   => 'https://boxnovel.com/wp-content/uploads/2019/04/rebirth-of-the-strongest-female-emperor-175x238.jpg'


	)
);
?>